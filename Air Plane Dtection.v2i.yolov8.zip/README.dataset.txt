# Air Plane Dtection > 2025-01-10 7:41pm
https://universe.roboflow.com/ahmad-qazii/air-plane-dtection

Provided by a Roboflow user
License: CC BY 4.0

